package com.springrest.springrest.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.springrest.springrest.entities.Patient;


@Repository
public interface IPatientDAO extends JpaRepository<Patient, Long> {
	
	@Query( value = "from Patient p where p.f_name= :name")
	abstract Patient findPatientByName(@PathVariable String name);
	
	
}

